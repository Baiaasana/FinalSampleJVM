package com.example.java_baia_asanidze;



//import lombok.Data;
//import lombok.EqualsAndHashCode;
//import lombok.NoArgsConstructor;
//import lombok.ToString;

import java.util.Objects;

//@NoArgsConstructor
//@Data
//@ToString
//@EqualsAndHashCode
public class FlightTicket {
    private int id;
    private String name;
    private int price;

    private String gza;

    public FlightTicket(int id, String name, int quantity, String gza) {
        this.id = id;
        this.name = name;
        this.price = quantity;
        this.gza = gza;
    }

    // Getter and Setter methods for the fields

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getGza() {
        return gza;
    }

    public void setGza(String name) {
        this.gza = gza;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    // Override methods

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        FlightTicket product = (FlightTicket) o;
        return Double.compare(product.price, price) == 0 &&
                price == product.price &&
                Objects.equals(name, product.name) &&
                Objects.equals(id, product.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, name, price);
    }

    @Override
    public String toString() {
        return "Product{" +
                "name='" + name + '\'' +
                ", id='" + id + '\'' +
                ", price=" + price + '\'' +
                ", gza=" + gza +
                '}';
    }
}

