package com.example.java_baia_asanidze;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Scene;
import javafx.scene.chart.PieChart;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;


import java.sql.*;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import java.io.IOException;

public class HelloApplication extends Application {

    private PieChart pieChart;

    public static void main(String[] args) {
        launch();
    }

    @Override
    public void start(Stage stage) throws IOException {

        // Set up UI components
        pieChart = new PieChart();
        TextField nameTextField = new TextField();
        nameTextField.setPromptText("Name");
        TextField priceTextField = new TextField();
        priceTextField.setPromptText("Price");

        TextField gzaTextField = new TextField();
        gzaTextField.setPromptText("gza");

        Button addButton = new Button("Add");
        addButton.setOnAction(event -> addTicket(nameTextField.getText(), gzaTextField.getText(), priceTextField.getText()));

        VBox vbox = new VBox(pieChart, nameTextField, priceTextField, gzaTextField, addButton);

        // Set up stage and scene
        Scene scene = new Scene(vbox);
        stage.setScene(scene);
        stage.setTitle("Tickets App");
        stage.show();

        // Load data
        loadTicketsFromDatabase();
    }

    private void addTicket(String name, String gza, String price2) {

        // Validate inputs
        if (name.isEmpty() || gza.isEmpty()|| price2.isEmpty()) {
            System.out.println("Please enter all name, price, gza.");
            return;
        }
        int price;
        try {
            price = Integer.parseInt(price2);
        } catch (NumberFormatException e) {
            System.out.println("Invalid price format. Please enter a valid integer value.");
            return;
        }

        // Perform database insertion using JDBC
        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/airports", "baiaasana", "baia@123");
             PreparedStatement statement = connection.prepareStatement("INSERT INTO tickets (name, price, gza) VALUES (?, ?, ?)")) {

            statement.setString(1, name);
            statement.setInt(2, price);
            statement.setString(3, gza);


            int rowsInserted = statement.executeUpdate();
            if (rowsInserted > 0) {
                System.out.println("Ticket added successfully!");
            } else {
                System.out.println("Failed to add Ticket.");
            }

            // After adding the product, update piechart.
            loadTicketsFromDatabase();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    private void loadTicketsFromDatabase() {

        // Use JDBC to connect to the MySQL database
        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/airports", "baiaasana", "baia@123"); PreparedStatement statement = connection.prepareStatement("SELECT * FROM tickets"); ResultSet resultSet = statement.executeQuery()) {

            ObservableList<FlightTicket> tickets = FXCollections.observableArrayList();
            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String name = resultSet.getString("name");
                int price = resultSet.getInt("price");
                String gza = resultSet.getString("gza");

                FlightTicket ticket = new FlightTicket(id, name, price, gza);
                tickets.add(ticket);
            }
            updatePieChart(tickets);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

//    private void updatePieChart(List<FlightTicket> tickets) {
//
//        // Group products by name and sum the quantities
//        Map<String, Integer> nameMap = tickets.stream()
//                .collect(Collectors.groupingBy(FlightTicket::getName, Collectors.summingInt(FlightTicket::getPrice)));
//
//        ObservableList<PieChart.Data> pieChartData = FXCollections.observableArrayList();
//
//        nameMap.forEach((name, price) -> {
//            String label = name + " (" + price + ")"; // Concatenate name and quantity
//            pieChartData.add(new PieChart.Data(label, price));
//        });
//
//        pieChart.setData(pieChartData);
//    }

    private void updatePieChart(List<FlightTicket> tickets) {
        pieChart.getData().clear();


        Map<String, List<FlightTicket>> ticketsbyprice = tickets.stream()
                .collect(Collectors.groupingBy(ticket -> {
                    if (ticket.getPrice() < 100) {
                        return "0-500";
                    } else if (ticket.getPrice() < 50) {
                        return "500-1000";
                    } else {
                        return "1000+";
                    }
                }));

        int totalCount = ticketsbyprice.values().stream()
                .mapToInt(List::size)
                .sum();

        ticketsbyprice.forEach((salaryRange, employees) -> {
            PieChart.Data data = new PieChart.Data(salaryRange + " (" + employees.size() + ")", employees.size());
            pieChart.getData().add(data);
        });

        pieChart.setTitle("Tickets range (All: " + totalCount + ")");
    }
}