module com.example.java_baia_asanidze {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;


    opens com.example.java_baia_asanidze to javafx.fxml;
    exports com.example.java_baia_asanidze;
}